
// ... (Previous imports remain same)
import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  AppContextType, Service, Product, Staff, Client, Appointment, Sale, Expense, StaffPayment, RegisterSession, Order, ViewMode, SocialUser, HairQuote, HairCalcConfig, AdminUser, Course, Student, LoyaltyReward, PointRedemption
} from '../types';
import { 
  INITIAL_SERVICES, INITIAL_PRODUCTS, INITIAL_STAFF, INITIAL_CLIENTS, INITIAL_APPOINTMENTS, INITIAL_SALES, INITIAL_EXPENSES, INITIAL_STAFF_PAYMENTS, INITIAL_REGISTER_SESSIONS, INITIAL_ORDERS, INITIAL_SOCIAL_USERS, INITIAL_HAIR_QUOTES, INITIAL_HAIR_CONFIG, INITIAL_ADMIN_USERS, INITIAL_COURSES, INITIAL_STUDENTS, INITIAL_LOYALTY_REWARDS, INITIAL_POINT_REDEMPTIONS
} from '../constants';

const DataContext = createContext<AppContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // ... (All other states remain same)
  const [viewMode, setViewMode] = useState<ViewMode>('client');
  const [currentUser, setCurrentUser] = useState<SocialUser | null>(null);
  const [currentAdmin, setCurrentAdmin] = useState<AdminUser | null>(null);
  const [loggedInClient, setLoggedInClient] = useState<Client | null>(null);

  const [services, setServices] = useState<Service[]>(INITIAL_SERVICES);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [courses, setCourses] = useState<Course[]>(INITIAL_COURSES);
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [staff, setStaff] = useState<Staff[]>(INITIAL_STAFF);
  const [clients, setClients] = useState<Client[]>(INITIAL_CLIENTS);
  const [appointments, setAppointments] = useState<Appointment[]>(INITIAL_APPOINTMENTS);
  const [sales, setSales] = useState<Sale[]>(INITIAL_SALES);
  const [expenses, setExpenses] = useState<Expense[]>(INITIAL_EXPENSES);
  const [staffPayments, setStaffPayments] = useState<StaffPayment[]>(INITIAL_STAFF_PAYMENTS);
  const [registerSessions, setRegisterSessions] = useState<RegisterSession[]>(INITIAL_REGISTER_SESSIONS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  
  const [socialUsers, setSocialUsers] = useState<SocialUser[]>(INITIAL_SOCIAL_USERS);
  const [hairQuotes, setHairQuotes] = useState<HairQuote[]>(INITIAL_HAIR_QUOTES);
  const [hairConfig, setHairConfig] = useState<HairCalcConfig>(INITIAL_HAIR_CONFIG);
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(INITIAL_ADMIN_USERS);
  const [loyaltyRewards, setLoyaltyRewards] = useState<LoyaltyReward[]>(INITIAL_LOYALTY_REWARDS);
  const [pointRedemptions, setPointRedemptions] = useState<PointRedemption[]>(INITIAL_POINT_REDEMPTIONS);

  // Persistence Logic
  useEffect(() => {
    const loaded = localStorage.getItem('celia_app_data');
    if (loaded) {
      try {
        const parsed = JSON.parse(loaded);
        if (parsed.services) setServices(parsed.services);
        if (parsed.products) setProducts(parsed.products);
        if (parsed.courses) setCourses(parsed.courses);
        if (parsed.students) setStudents(parsed.students);
        if (parsed.staff) setStaff(parsed.staff);
        if (parsed.clients) setClients(parsed.clients);
        if (parsed.appointments) setAppointments(parsed.appointments);
        if (parsed.sales) setSales(parsed.sales);
        if (parsed.expenses) setExpenses(parsed.expenses);
        if (parsed.staffPayments) setStaffPayments(parsed.staffPayments);
        if (parsed.registerSessions) setRegisterSessions(parsed.registerSessions);
        if (parsed.orders) setOrders(parsed.orders);
        if (parsed.socialUsers) setSocialUsers(parsed.socialUsers);
        if (parsed.hairQuotes) setHairQuotes(parsed.hairQuotes);
        if (parsed.hairConfig) setHairConfig(parsed.hairConfig);
        if (parsed.adminUsers) setAdminUsers(parsed.adminUsers);
        if (parsed.loyaltyRewards) setLoyaltyRewards(parsed.loyaltyRewards);
        if (parsed.pointRedemptions) setPointRedemptions(parsed.pointRedemptions);
      } catch (e) {
        console.error("Failed to load data", e);
      }
    }
  }, []);

  useEffect(() => {
    const data = { 
      services, products, courses, students, staff, clients, appointments, sales, expenses, 
      staffPayments, registerSessions, orders, socialUsers, hairQuotes, hairConfig, adminUsers, loyaltyRewards, pointRedemptions
    };
    try {
      localStorage.setItem('celia_app_data', JSON.stringify(data));
    } catch (e) {
      // Swallow error
    }
  }, [services, products, courses, students, staff, clients, appointments, sales, expenses, staffPayments, registerSessions, orders, socialUsers, hairQuotes, hairConfig, adminUsers, loyaltyRewards, pointRedemptions]);

  // Actions (Abbreviated common CRUD for brevity, focus on Redeem)
  const addService = (item: Service) => setServices(prev => [...prev, item]);
  const updateService = (item: Service) => setServices(prev => prev.map(i => i.id === item.id ? item : i));
  const removeService = (id: string) => setServices(prev => prev.filter(i => i.id !== id));

  const addProduct = (item: Product) => setProducts(prev => [...prev, item]);
  const updateProduct = (item: Product) => setProducts(prev => prev.map(i => i.id === item.id ? item : i));
  const removeProduct = (id: string) => setProducts(prev => prev.filter(i => i.id !== id));

  const addCourse = (item: Course) => setCourses(prev => [...prev, item]);
  const updateCourse = (item: Course) => setCourses(prev => prev.map(i => i.id === item.id ? item : i));
  const removeCourse = (id: string) => setCourses(prev => prev.filter(i => i.id !== id));

  const addStudent = (item: Student) => setStudents(prev => [...prev, item]);
  const updateStudent = (item: Student) => setStudents(prev => prev.map(i => i.id === item.id ? item : i));
  const removeStudent = (id: string) => setStudents(prev => prev.filter(i => i.id !== id));

  const addStaff = (item: Staff) => setStaff(prev => [...prev, item]);
  const updateStaff = (item: Staff) => setStaff(prev => prev.map(i => i.id === item.id ? item : i));
  const removeStaff = (id: string) => setStaff(prev => prev.filter(i => i.id !== id));

  const addClient = (item: Client) => setClients(prev => [...prev, item]);
  const updateClient = (item: Client) => setClients(prev => prev.map(i => i.id === item.id ? item : i));
  const removeClient = (id: string) => setClients(prev => prev.filter(i => i.id !== id));

  const addAppointment = (item: Appointment) => setAppointments(prev => [...prev, item]);
  const updateAppointment = (item: Appointment) => setAppointments(prev => prev.map(i => i.id === item.id ? item : i));

  const addSale = (sale: Sale) => {
    setSales(prev => [...prev, sale]);
    setProducts(prevProducts => prevProducts.map(product => {
      const soldItems = sale.items.filter(item => item.type === 'product' && item.id === product.id);
      if (soldItems.length === 0) return product;
      let totalDeduction = 0;
      soldItems.forEach(item => {
        let quantityToDeduct = item.quantity;
        if (product.unit === 'kg') { if (item.unit === 'g') quantityToDeduct = item.quantity / 1000; } 
        else if (product.unit === 'g') { if (item.unit === 'kg') quantityToDeduct = item.quantity * 1000; }
        totalDeduction += quantityToDeduct;
      });
      return { ...product, stock: Math.max(0, product.stock - totalDeduction) };
    }));
    sale.items.forEach(item => {
      if (item.type === 'product') {
        const product = products.find(p => p.id === item.id);
        if (product && product.hairQuoteId) {
           setHairQuotes(prevQuotes => prevQuotes.map(q => q.id === product.hairQuoteId ? { ...q, status: 'sold' } : q));
        }
      }
    });
  };

  const addExpense = (item: Expense) => setExpenses(prev => [...prev, item]);
  const addStaffPayment = (item: StaffPayment) => setStaffPayments(prev => [...prev, item]);

  // Register
  const getCurrentSession = () => registerSessions.find(s => s.status === 'open');
  const openRegister = (amount: number) => { if (getCurrentSession()) return; setRegisterSessions(prev => [...prev, { id: `reg-${Date.now()}`, openedAt: new Date().toISOString(), openingBalance: amount, status: 'open' }]); };
  const closeRegister = (withdrawAmount: number) => {
    setRegisterSessions(prev => prev.map(session => {
      if (session.status === 'open') {
        const sessionStart = new Date(session.openedAt).getTime();
        const sessionSales = sales.filter(s => new Date(s.date).getTime() >= sessionStart);
        const sessionExpenses = expenses.filter(e => new Date(e.date).getTime() >= sessionStart);
        const totalIncome = sessionSales.reduce((acc, sale) => {
           return acc + sale.items.reduce((itemAcc, item) => (item.origin !== 'hair_business' ? itemAcc + (item.price * item.quantity) : itemAcc), 0);
        }, 0);
        const totalExpenses = sessionExpenses.reduce((acc, e) => (e.businessUnit !== 'hair_business' ? acc + e.amount : acc), 0);
        return { ...session, status: 'closed', closedAt: new Date().toISOString(), totalIncome, totalExpenses, calculatedBalance: session.openingBalance + totalIncome - totalExpenses, withdrawnAmount: withdrawAmount, finalBalance: (session.openingBalance + totalIncome - totalExpenses) - withdrawAmount };
      }
      return session;
    }));
  };

  const addOrder = (order: Order) => setOrders(prev => [...prev, order]);
  const updateOrder = (updatedOrder: Order) => {
    const currentOrder = orders.find(o => o.id === updatedOrder.id);
    setOrders(prev => prev.map(o => o.id === updatedOrder.id ? updatedOrder : o));
    if (!currentOrder) return;
    if (updatedOrder.status === 'completed' && currentOrder.status !== 'completed') {
       let orderClientId = 'online-customer';
       let orderClientName = updatedOrder.customerName;
       if (updatedOrder.clientId) { orderClientId = updatedOrder.clientId; } 
       else {
           const matchedClient = clients.find(c => (c.phone && c.phone.includes(updatedOrder.customerWhatsapp)) || (c.name && c.name.toLowerCase() === updatedOrder.customerName.toLowerCase()));
           if (matchedClient) { orderClientId = matchedClient.id; orderClientName = matchedClient.name; }
       }
       const newSale: Sale = {
          id: `sale-ord-${updatedOrder.id}`,
          date: new Date().toISOString(),
          clientId: orderClientId, 
          clientName: orderClientName,
          customerCpf: updatedOrder.customerCpf,
          total: updatedOrder.total,
          paymentMethod: 'pix',
          items: updatedOrder.items.map(orderItem => {
             const prod = products.find(p => p.id === orderItem.productId);
             const course = courses.find(c => c.id === orderItem.productId);
             let origin: 'store' | 'hair_business' = 'store';
             let itemType: 'product' | 'course' = 'product';
             if (prod) { origin = prod.origin || 'store'; } 
             else if (course) { origin = 'store'; itemType = 'course'; }
             return { type: itemType, id: orderItem.productId, name: orderItem.productName, quantity: orderItem.quantity, unit: orderItem.unit, price: orderItem.price, staffId: 'system-online', staffName: 'Venda Online', origin: origin };
          })
       };
       addSale(newSale);
    }
    if (updatedOrder.status === 'cancelled' && currentOrder.status === 'completed') {
       updatedOrder.items.forEach(item => {
          setProducts(prev => prev.map(p => {
             if (p.id === item.productId) {
                 let quantityToAdd = item.quantity;
                 if (p.unit === 'kg' && item.unit === 'g') quantityToAdd /= 1000;
                 else if (p.unit === 'g' && item.unit === 'kg') quantityToAdd *= 1000;
                 return { ...p, stock: p.stock + quantityToAdd };
             }
             return p;
          }));
          const product = products.find(p => p.id === item.productId);
          if (product && product.hairQuoteId) { setHairQuotes(prev => prev.map(q => q.id === product.hairQuoteId ? { ...q, status: 'stock' } : q)); }
       });
    }
  };

  const addSocialUser = (user: SocialUser) => setSocialUsers(prev => [...prev, user]);
  const updateSocialUser = (user: SocialUser) => setSocialUsers(prev => prev.map(u => u.id === user.id ? user : u));
  const removeSocialUser = (id: string) => setSocialUsers(prev => prev.filter(u => u.id !== id));
  
  const addHairQuote = (quote: HairQuote) => setHairQuotes(prev => [...prev, quote]);
  const updateHairQuote = (quote: HairQuote) => setHairQuotes(prev => prev.map(q => q.id === quote.id ? quote : q));
  const updateHairConfig = (config: HairCalcConfig) => setHairConfig(config);
  const registerHairPurchase = (quote: HairQuote) => {
    setHairQuotes(prev => prev.map(q => q.id === quote.id ? quote : q));
    setExpenses(prev => [...prev, { id: `exp-hair-${Date.now()}`, description: `Compra de Cabelo: ${quote.hairType} (${quote.sellerName})`, amount: quote.totalValue, date: new Date().toISOString(), category: 'Compra de Cabelo', businessUnit: 'hair_business' }]);
  };

  const addAdminUser = (user: AdminUser) => setAdminUsers(prev => [...prev, user]);
  const updateAdminUser = (user: AdminUser) => setAdminUsers(prev => prev.map(u => u.id === user.id ? user : u));
  const removeAdminUser = (id: string) => setAdminUsers(prev => prev.filter(u => u.id !== id));

  const addLoyaltyReward = (reward: LoyaltyReward) => setLoyaltyRewards(prev => [...prev, reward]);
  const removeLoyaltyReward = (id: string) => setLoyaltyRewards(prev => prev.filter(r => r.id !== id));
  
  // FIX: Ensure ID matching and state update consistency
  const redeemPoints = (clientId: string, reward: LoyaltyReward) => {
      const code = `#DESC-${Date.now().toString().slice(-4)}`;
      const redemption: PointRedemption = {
          id: `red-${Date.now()}`,
          clientId,
          rewardId: reward.id,
          rewardTitle: reward.title,
          pointsCost: reward.pointsCost,
          date: new Date().toISOString(),
          code: code
      };
      setPointRedemptions(prev => [...prev, redemption]);

      if (reward.stock !== undefined) {
          setLoyaltyRewards(prev => prev.map(r => r.id === reward.id ? { ...r, stock: r.stock ? r.stock - 1 : 0 } : r));
      }
  };

  return (
    <DataContext.Provider value={{
      viewMode, setViewMode, currentUser, setCurrentUser, currentAdmin, setCurrentAdmin, loggedInClient, setLoggedInClient,
      services, products, courses, students, staff, clients, appointments, sales, expenses, staffPayments, registerSessions, orders, socialUsers, hairQuotes, hairConfig, adminUsers, loyaltyRewards, pointRedemptions,
      addService, updateService, removeService, addProduct, updateProduct, removeProduct, addCourse, updateCourse, removeCourse,
      addStudent, updateStudent, removeStudent, addStaff, updateStaff, removeStaff, addClient, updateClient, removeClient,
      addAppointment, updateAppointment, addSale, addExpense, addStaffPayment,
      openRegister, closeRegister, getCurrentSession, addOrder, updateOrder,
      addSocialUser, updateSocialUser, removeSocialUser, addHairQuote, updateHairQuote, updateHairConfig, registerHairPurchase,
      addAdminUser, updateAdminUser, removeAdminUser, addLoyaltyReward, removeLoyaltyReward, redeemPoints
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error("useData must be used within DataProvider");
  return context;
};
